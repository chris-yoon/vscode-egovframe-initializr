package org.egovframe.cloud.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryApplicationTests {

    @Test
    void contextLoads() {
    }

}
