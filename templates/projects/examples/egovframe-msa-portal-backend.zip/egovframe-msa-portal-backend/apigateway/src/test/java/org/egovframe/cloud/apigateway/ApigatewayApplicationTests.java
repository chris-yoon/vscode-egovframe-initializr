package org.egovframe.cloud.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles(profiles = "test")
@SpringBootTest
class ApigatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
