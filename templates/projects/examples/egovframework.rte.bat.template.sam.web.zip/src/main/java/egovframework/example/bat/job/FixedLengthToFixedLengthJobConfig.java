package egovframework.example.bat.job;

import java.net.MalformedURLException;

import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.egovframe.rte.bat.core.item.file.transform.EgovFieldExtractor;
import org.egovframe.rte.bat.core.item.file.transform.EgovFixedLengthLineAggregator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

import egovframework.example.bat.transform.EgovDefaultLineMapper;
import egovframework.example.bat.transform.EgovFixedLengthTokenizer;

@Configuration
public class FixedLengthToFixedLengthJobConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(FixedLengthToFixedLengthJobConfig.class);
	
	@Autowired
    private JobBuilderFactory jobBuilderFactory;
	@Autowired
    private StepBuilderFactory stepBuilderFactory;
	
    @Bean
    public Job fixedLengthToFixedLengthJob() {
        return jobBuilderFactory.get("fixedLengthToFixedLengthJob")
                .start(fixedLengthToFixedLengthStep())
                .build();
    }

    @Bean
    public Step fixedLengthToFixedLengthStep() {
        return stepBuilderFactory.get("fixedLengthToFixedLengthStep")
                .<CustomerCredit,CustomerCredit>chunk(2)
                .reader(fixedLengthItemReader(null))
                .processor(itemProcessor())
                .writer(fixedLengthItemWriter(null))
                .build();
    }
    
    @Bean
    @StepScope
    @Value("#{jobParameters[inputFile]}")
    public FlatFileItemReader<CustomerCredit> fixedLengthItemReader(String inputFile) {
    	
    	LOGGER.debug("===>>> inputFile = "+inputFile);
    	Resource resource = null;
		try {
			resource = new UrlResource(inputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
        return new FlatFileItemReaderBuilder<CustomerCredit>()
        		.name("fixedLengthItemReader")
        		.resource(resource)
        		.lineMapper(defaultLineMapper())
        		.saveState(false)
        		.build();
    }

    @Bean
    public EgovFixedLengthTokenizer lineTokenizer() {
    	EgovFixedLengthTokenizer fixedLengthTokenizer = new EgovFixedLengthTokenizer();
    	fixedLengthTokenizer.setColumns(new Range[]{new Range(1, 9), new Range(10, 11)});
    	return fixedLengthTokenizer;
    }
    
    @Bean
    public EgovObjectMapper<CustomerCredit> objectMapper() {
    	EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name","credit"});
		return objectMapper;
    }
    
    @Bean
    public EgovDefaultLineMapper<CustomerCredit> defaultLineMapper() {
    	EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
    	lineMapper.setLineTokenizer(lineTokenizer());
    	lineMapper.setObjectMapper(objectMapper());
    	return lineMapper;
    }
    
    @Bean
    public CustomerCreditIncreaseProcessor itemProcessor() {
        return new CustomerCreditIncreaseProcessor();
    }

    @Bean
    @StepScope
    @Value("#{jobParameters[outputFile]}")
    public FlatFileItemWriter<CustomerCredit> fixedLengthItemWriter(String outputFile) {
    	
    	LOGGER.debug("===>>> outputFile = "+outputFile);
    	
    	Resource resource = null;
		try {
			resource = new UrlResource(outputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
    	return new FlatFileItemWriterBuilder<CustomerCredit>()
    			.name("fixedLengthItemWriter")
    			.resource(resource)
    			.lineAggregator(lineAggregator())
    			.saveState(false)
    			.build();
    }
    
    @Bean
    public EgovFieldExtractor<CustomerCredit> fieldExtractor() {
    	EgovFieldExtractor<CustomerCredit> fieldExtractor = new EgovFieldExtractor<>();
    	fieldExtractor.setNames(new String[] {"name","credit"});
    	return fieldExtractor;
    }
    
    @Bean
    public EgovFixedLengthLineAggregator<CustomerCredit> lineAggregator() {
    	EgovFixedLengthLineAggregator<CustomerCredit> lineAggregator = new EgovFixedLengthLineAggregator<>();
    	lineAggregator.setFieldRanges(new int[] {9,2});
    	lineAggregator.setFieldExtractor(fieldExtractor());
    	return lineAggregator;
    }
}
