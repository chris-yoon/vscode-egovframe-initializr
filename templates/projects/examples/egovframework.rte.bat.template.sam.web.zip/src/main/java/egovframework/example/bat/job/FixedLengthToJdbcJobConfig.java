package egovframework.example.bat.job;

import java.net.MalformedURLException;

import javax.sql.DataSource;

import org.egovframe.rte.bat.core.item.database.EgovJdbcBatchItemWriter;
import org.egovframe.rte.bat.core.item.database.support.EgovMethodMapItemPreparedStatementSetter;
import org.egovframe.rte.bat.core.item.file.mapping.EgovObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import egovframework.example.bat.domain.trade.CustomerCredit;
import egovframework.example.bat.domain.trade.CustomerCreditIncreaseProcessor;

import egovframework.example.bat.transform.EgovDefaultLineMapper;
import egovframework.example.bat.transform.EgovFixedLengthTokenizer;

@Configuration
public class FixedLengthToJdbcJobConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(FixedLengthToJdbcJobConfig.class);
	
	@Autowired
    private JobBuilderFactory jobBuilderFactory;
	@Autowired
    private StepBuilderFactory stepBuilderFactory;
	
    @Bean
    public Job fixedLengthToJdbcJob() {
        return jobBuilderFactory.get("fixedLengthToJdbcJob")
                .start(fixedLengthToJdbcStep())
                .build();
    }

    @Bean
    public Step fixedLengthToJdbcStep() {
        return stepBuilderFactory.get("fixedLengthToJdbcStep")
                .<CustomerCredit,CustomerCredit>chunk(2)
                .reader(fixedLengthItemReader(null))
                .processor(itemProcessor())
                .writer(jdbcBatchItemWriter(null))
                .build();
    }
    
    @Bean
    @StepScope
    @Value("#{jobParameters[inputFile]}")
    public FlatFileItemReader<CustomerCredit> fixedLengthItemReader(String inputFile) {
    	
    	LOGGER.debug("===>>> inputFile = "+inputFile);
    	Resource resource = null;
		try {
			resource = new UrlResource(inputFile);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
    	
        return new FlatFileItemReaderBuilder<CustomerCredit>()
        		.name("fixedLengthItemReader")
        		.resource(resource)
        		.lineMapper(defaultLineMapper())
        		.saveState(false)
        		.build();
    }

    @Bean
    public EgovFixedLengthTokenizer lineTokenizer() {
    	EgovFixedLengthTokenizer fixedLengthTokenizer = new EgovFixedLengthTokenizer();
    	fixedLengthTokenizer.setColumns(new Range[]{new Range(1, 9), new Range(10, 11)});
    	return fixedLengthTokenizer;
    }
    
    @Bean
    public EgovObjectMapper<CustomerCredit> objectMapper() {
    	EgovObjectMapper<CustomerCredit> objectMapper = new EgovObjectMapper<>();
		objectMapper.setType(CustomerCredit.class);
		objectMapper.setNames(new String[] {"name","credit"});
		return objectMapper;
    }
    
    @Bean
    public EgovDefaultLineMapper<CustomerCredit> defaultLineMapper() {
    	EgovDefaultLineMapper<CustomerCredit> lineMapper = new EgovDefaultLineMapper<>();
    	lineMapper.setLineTokenizer(lineTokenizer());
    	lineMapper.setObjectMapper(objectMapper());
    	return lineMapper;
    }
    
    @Bean
    public CustomerCreditIncreaseProcessor itemProcessor() {
        return new CustomerCreditIncreaseProcessor();
    }

    @Bean
    @StepScope
    public EgovJdbcBatchItemWriter<CustomerCredit> jdbcBatchItemWriter(DataSource dataSource) {
    	
		EgovJdbcBatchItemWriter<CustomerCredit> jdbcBatchItemWriter	= new EgovJdbcBatchItemWriter<>();
		jdbcBatchItemWriter.setAssertUpdates(true);
		jdbcBatchItemWriter.setItemPreparedStatementSetter(itemPreparedStatementSetter());
		jdbcBatchItemWriter.setSql("UPDATE CUSTOMER set credit =? where name =?");
		jdbcBatchItemWriter.setParams(new String[] {"credit","name"});
		jdbcBatchItemWriter.setDataSource(dataSource);
		
    	return jdbcBatchItemWriter;
    }
    
    @Bean
    public EgovMethodMapItemPreparedStatementSetter<CustomerCredit> itemPreparedStatementSetter() {
    	return new EgovMethodMapItemPreparedStatementSetter<>();
    }
    
}
